# data_cache EDGAR delta — fondamentali US 2009-2019 (Sess.36, B-042)

Prodotto dal fetch live SEC EDGAR companyfacts (full roster sp500, 496 ticker).
Copertura 84-92% dal 2011 (2009 = 44%, phase-in XBRL).

Contenuto: fmp_{income,balance,cashflow}_{2009..2019}.parquet + fmp_profile.parquet
(schema FMP-raw, già consumabile da data_layer.load_from_cache senza adapter).

Per ricostruire la cache estesa 2009-2024 servono anche i prezzi storici yfinance
(scripts/_fetch_prices_hist.py) e l'assemblaggio descritto in
docs/TASK_B042_EXTENDED_2009_2024.md.
