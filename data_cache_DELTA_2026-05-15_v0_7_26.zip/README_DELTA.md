# data_cache_DELTA — Sess.32 (2026-05-15) — Quality Framework v0.7.26

## Contenuto

`data_cache_simfin/` — bulk SimFin storico 2020-2024 nello schema FMP-raw compatible.

- **16 parquet** (~2.4 MB totali):
  - `fmp_income_{2020..2024}.parquet`
  - `fmp_balance_{2020..2024}.parquet`
  - `fmp_cashflow_{2020..2024}.parquet`
  - `fmp_profile.parquet` (stub, 4417 ticker unici, sector reale, marketCap=NaN)
  - `_meta.json` (sentinel `source="simfin_bulk"`, `schema="fmp_raw_compatible_v1"`)

- **Ticker/anno**: 2020=3594, 2021=3697, 2022=3621, 2023=3243, 2024=2888.
- **Righe totali**: ~51000 (3 statement × 5 anni).

## Come installare

Estrarre il contenuto nella root del framework v0.7.26:

```bash
cd quality_framework_v0.7.26_2026-05-15/
unzip data_cache_DELTA_2026-05-15_v0_7_26.zip
# Risultato: data_cache_simfin/ accanto a data_cache/
```

## Caveat

1. **Separato da `data_cache/` (FMP)**: non sovrascrive i bilanci FMP esistenti. Pipeline backtest baseline invariata.
2. **Banks/Insurance esclusi**: SimFin "us-shares" dataset only.
3. **market_cap NaN**: da popolare via yfinance in Sess.33 (prerequisito A di B-031b).
4. **Cross-source AAPL/MSFT vs FMP 5-year**: 80% bit-identical; nuove discrepanze su MSFT share_repurchases (~5-11% sistematica), MSFT OCF/FCF 2020-21 (~2-7%), AAPL long_term_debt 2023-24 (~10-12%). Vedi `docs/TASK_B031b_US_HISTORICAL_BACKTEST.md`.

## NON incluso

- **`.simfin_cache/`** (~21 MB CSV bulk SimFin): rigenerabile via `scripts/fetch_simfin_bulk.py` in pochi minuti. Non spedito per peso, ricreabile in Sess.33 se serve.
