# Data Cache Delta — 0.7.19 (Sess.27 2026-05-11)

Delta cumulativo dei file `data_cache/` modificati o aggiunti in Sess.27 rispetto al baseline 0.7.18.

## File in questo delta

### `data_cache/yfinance_benchmarks.parquet`
- **Pre-Sess.27 (0.7.18)**: 1624 righe, 2 ticker (SPY, URTH).
- **Post-Sess.27 (0.7.19)**: 8143 righe, 10 ticker (SPY, URTH + 4 US factor + 4 UCITS world factor).
- **Aggiunti**:
  - US factor ETF (B-036 fallback): QUAL, MTUM, VLUE, USMV (812 righe ciascuno, 2022-04-01 → 2025-06-27).
  - UCITS world factor ETF (B-036 primary): IS3R.DE (Xetra Quality), IWMO.L (LSE Momentum), IWVL.L (LSE Value), MVOL.L (LSE MinVolatility) — 815-826 righe ciascuno.
- **Note**: IQLT.L (originally planned per Sess.26 backlog B-036) **non coperto da yfinance** ("possibly delisted; no timezone found"). Sostituito con `IS3R.DE` Xetra come Quality UCITS alternativa funzionante (decisione Sess.27 confermata utente).

## Come applicare il delta

Sovrascrivere il `data_cache/yfinance_benchmarks.parquet` del baseline 0.7.18 con questa versione. Tutti gli altri file della cache (`fmp_*.parquet`, `fx_rates.parquet`, `market_cap_history.parquet`, `yfinance_returns.parquet`, ecc.) sono **invariati** rispetto a 0.7.18 e non sono inclusi qui.

Verifica post-applicazione:
```python
import pandas as pd
b = pd.read_parquet('data_cache/yfinance_benchmarks.parquet')
print(b.groupby('symbol').size())
# Atteso:
# symbol
# IS3R.DE    826
# IWMO.L     815
# IWVL.L     815
# MTUM       812
# MVOL.L     815
# QUAL       812
# SPY        812
# URTH       812
# USMV       812
# VLUE       812
```

Riferimento doc: `docs/CHANGELOG.md` § 0.7.19, `docs/BACKLOG.md` § B-036.
